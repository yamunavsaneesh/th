<title><?php echo $this->pagetitle; ?> - <?php echo $this->alphasettings['SITE_NAME']; ?></title>
<meta name="description" content= "<?php echo $this->desc; ?>" />
<meta name="keywords" content="<?php echo $this->keys; ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1">