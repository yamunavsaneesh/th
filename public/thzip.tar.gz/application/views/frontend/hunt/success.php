<div class="timing">
  <div class="row">
    <div class="col-xs-5">
      <p>Stage <span class="num"><?php echo $total ?></span> of <span class="num"><?php echo $total ?></span></p>
    </div>
    <div class="col-xs-7">       
    </div>
  </div>
</div>
<p class="text-center start-txt">Congratulations....<br />
You have completed the Hunt.<br />
<span class="red">Please wait for the results...</span></p>
