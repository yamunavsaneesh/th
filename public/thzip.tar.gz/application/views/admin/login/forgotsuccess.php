<div class="forgot_success">
<h3>Password reset link send to corresponding email account.</h3>
<a class="button" href="<?php echo site_url('admin/login'); ?>">Back to Login</a>
</div>
