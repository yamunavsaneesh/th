<div class="forgot_success">
<h3>Password Reset Successfull.</h3>
<a class="button" href="<?php echo site_url('admin/login'); ?>">Back to Login</a>
</div>
