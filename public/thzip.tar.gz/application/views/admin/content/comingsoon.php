<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="card">
      <div class="app-heading">
        <div class="app-title">
          <p class="mt30">&nbsp;</p>
          <div class="title"><span class="highlight">Coming Soon</span></div>
        </div>
      </div>
      <div class="card-body">
        <div class="content">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
              <p>Coming Soon...</p>
            </div>
          </div>
        </div>
        <?php echo form_close(); ?> </div>
    </div>
  </div>
</div>
