 <footer class="app-footer"> 
  <div class="row">
    <div class="col-xs-12">
      <div class="footer-copyright"><?php echo $this->config->item('copyright'); ?> </div>
    </div>
  </div>
</footer>