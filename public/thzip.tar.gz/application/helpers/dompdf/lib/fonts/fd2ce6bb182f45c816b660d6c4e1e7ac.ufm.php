<?php return array (
  'codeToName' => 
  array (
    0 => 'glyph1',
    32 => 'space',
    33 => 'exclam',
    34 => 'quotedbl',
    35 => 'numbersign',
    36 => 'dollar',
    37 => 'percent',
    38 => 'ampersand',
    39 => 'quotesingle',
    40 => 'parenleft',
    41 => 'parenright',
    42 => 'asterisk',
    43 => 'plus',
    44 => 'comma',
    45 => 'hyphen',
    46 => 'period',
    47 => 'slash',
    48 => 'zero',
    49 => 'one',
    50 => 'two',
    51 => 'three',
    52 => 'four',
    53 => 'five',
    54 => 'six',
    55 => 'seven',
    56 => 'eight',
    57 => 'nine',
    58 => 'colon',
    59 => 'semicolon',
    60 => 'less',
    61 => 'equal',
    62 => 'greater',
    63 => 'question',
    64 => 'at',
    65 => 'A',
    66 => 'B',
    67 => 'C',
    68 => 'D',
    69 => 'E',
    70 => 'F',
    71 => 'G',
    72 => 'H',
    73 => 'I',
    74 => 'J',
    75 => 'K',
    76 => 'L',
    77 => 'M',
    78 => 'N',
    79 => 'O',
    80 => 'P',
    81 => 'Q',
    82 => 'R',
    83 => 'S',
    84 => 'T',
    85 => 'U',
    86 => 'V',
    87 => 'W',
    88 => 'X',
    89 => 'Y',
    90 => 'Z',
    91 => 'bracketleft',
    92 => 'backslash',
    93 => 'bracketright',
    94 => 'asciicircum',
    95 => 'underscore',
    96 => 'grave',
    97 => 'a',
    98 => 'b',
    99 => 'c',
    100 => 'd',
    101 => 'e',
    102 => 'f',
    103 => 'g',
    104 => 'h',
    105 => 'i',
    106 => 'j',
    107 => 'k',
    108 => 'l',
    109 => 'm',
    110 => 'n',
    111 => 'o',
    112 => 'p',
    113 => 'q',
    114 => 'r',
    115 => 's',
    116 => 't',
    117 => 'u',
    118 => 'v',
    119 => 'w',
    120 => 'x',
    121 => 'y',
    122 => 'z',
    123 => 'braceleft',
    124 => 'bar',
    125 => 'braceright',
    126 => 'asciitilde',
    161 => 'exclamdown',
    162 => 'cent',
    163 => 'sterling',
    164 => 'currency',
    165 => 'yen',
    166 => 'brokenbar',
    167 => 'section',
    168 => 'dieresis',
    169 => 'copyright',
    170 => 'ordfeminine',
    171 => 'guillemotleft',
    172 => 'logicalnot',
    174 => 'registered',
    175 => 'macron',
    176 => 'degree',
    177 => 'plusminus',
    180 => 'acute',
    182 => 'paragraph',
    183 => 'periodcentered',
    184 => 'cedilla',
    186 => 'ordmasculine',
    187 => 'guillemotright',
    188 => 'onequarter',
    189 => 'onehalf',
    190 => 'threequarters',
    191 => 'questiondown',
    192 => 'Agrave',
    193 => 'Aacute',
    194 => 'Acircumflex',
    195 => 'Atilde',
    196 => 'Adieresis',
    197 => 'Aring',
    198 => 'AE',
    199 => 'Ccedilla',
    200 => 'Egrave',
    201 => 'Eacute',
    202 => 'Ecircumflex',
    203 => 'Edieresis',
    204 => 'Igrave',
    205 => 'Iacute',
    206 => 'Icircumflex',
    207 => 'Idieresis',
    208 => 'Eth',
    209 => 'Ntilde',
    210 => 'Ograve',
    211 => 'Oacute',
    212 => 'Ocircumflex',
    213 => 'Otilde',
    214 => 'Odieresis',
    215 => 'multiply',
    216 => 'Oslash',
    217 => 'Ugrave',
    218 => 'Uacute',
    219 => 'Ucircumflex',
    220 => 'Udieresis',
    221 => 'Yacute',
    222 => 'Thorn',
    223 => 'germandbls',
    224 => 'agrave',
    225 => 'aacute',
    226 => 'acircumflex',
    227 => 'atilde',
    228 => 'adieresis',
    229 => 'aring',
    230 => 'ae',
    231 => 'ccedilla',
    232 => 'egrave',
    233 => 'eacute',
    234 => 'ecircumflex',
    235 => 'edieresis',
    236 => 'igrave',
    237 => 'iacute',
    238 => 'icircumflex',
    239 => 'idieresis',
    240 => 'eth',
    241 => 'ntilde',
    242 => 'ograve',
    243 => 'oacute',
    244 => 'ocircumflex',
    245 => 'otilde',
    246 => 'odieresis',
    247 => 'divide',
    248 => 'oslash',
    249 => 'ugrave',
    250 => 'uacute',
    251 => 'ucircumflex',
    252 => 'udieresis',
    253 => 'yacute',
    254 => 'thorn',
    255 => 'ydieresis',
    338 => 'OE',
    339 => 'oe',
    376 => 'Ydieresis',
    710 => 'circumflex',
    732 => 'tilde',
    8210 => 'figuredash',
    8211 => 'endash',
    8212 => 'emdash',
    8216 => 'quoteleft',
    8217 => 'quoteright',
    8218 => 'quotesinglbase',
    8220 => 'quotedblleft',
    8221 => 'quotedblright',
    8222 => 'quotedblbase',
    8226 => 'bullet',
    8230 => 'ellipsis',
    8249 => 'guilsinglleft',
    8250 => 'guilsinglright',
    8364 => 'Euro',
    8482 => 'trademark',
  ),
  'isUnicode' => true,
  'EncodingScheme' => 'FontSpecific',
  'FontName' => 'Open Sans Semibold',
  'FullName' => 'Open Sans Semibold Regular',
  'Version' => 'Version 1.10',
  'PostScriptName' => 'OpenSans-Semibold',
  'Weight' => 'Bold',
  'ItalicAngle' => '0',
  'IsFixedPitch' => 'false',
  'UnderlineThickness' => '50',
  'UnderlinePosition' => '-75',
  'FontHeightOffset' => '0',
  'Ascender' => '1049',
  'Descender' => '-302',
  'FontBBox' => 
  array (
    0 => '-76',
    1 => '-240',
    2 => '960',
    3 => '931',
  ),
  'StartCharMetrics' => '234',
  'C' => 
  array (
    0 => 1000,
    13 => 510,
    32 => 260,
    33 => 276,
    34 => 436,
    35 => 646,
    36 => 571,
    37 => 862,
    38 => 740,
    39 => 243,
    40 => 317,
    41 => 317,
    42 => 548,
    43 => 571,
    44 => 267,
    45 => 322,
    46 => 275,
    47 => 390,
    48 => 571,
    49 => 571,
    50 => 571,
    51 => 571,
    52 => 571,
    53 => 571,
    54 => 571,
    55 => 571,
    56 => 571,
    57 => 571,
    58 => 275,
    59 => 278,
    60 => 571,
    61 => 571,
    62 => 571,
    63 => 453,
    64 => 898,
    65 => 661,
    66 => 660,
    67 => 634,
    68 => 734,
    69 => 558,
    70 => 532,
    71 => 726,
    72 => 751,
    73 => 305,
    74 => 299,
    75 => 639,
    76 => 542,
    77 => 923,
    78 => 783,
    79 => 787,
    80 => 615,
    81 => 787,
    82 => 639,
    83 => 550,
    84 => 566,
    85 => 742,
    86 => 622,
    87 => 946,
    88 => 622,
    89 => 592,
    90 => 575,
    91 => 330,
    92 => 390,
    93 => 330,
    94 => 537,
    95 => 429,
    96 => 592,
    97 => 580,
    98 => 623,
    99 => 495,
    100 => 623,
    101 => 576,
    102 => 363,
    103 => 556,
    104 => 635,
    105 => 279,
    106 => 279,
    107 => 572,
    108 => 279,
    109 => 956,
    110 => 635,
    111 => 611,
    112 => 623,
    113 => 623,
    114 => 431,
    115 => 487,
    116 => 393,
    117 => 635,
    118 => 535,
    119 => 817,
    120 => 551,
    121 => 536,
    122 => 478,
    123 => 386,
    124 => 551,
    125 => 371,
    126 => 571,
    160 => 260,
    161 => 276,
    162 => 571,
    163 => 571,
    164 => 571,
    165 => 571,
    166 => 551,
    167 => 501,
    168 => 592,
    169 => 832,
    170 => 368,
    171 => 556,
    172 => 571,
    173 => 322,
    174 => 832,
    175 => 500,
    176 => 428,
    177 => 571,
    178 => 363,
    179 => 363,
    180 => 592,
    181 => 639,
    182 => 655,
    183 => 275,
    184 => 216,
    185 => 363,
    186 => 381,
    187 => 556,
    188 => 830,
    189 => 830,
    190 => 830,
    191 => 453,
    192 => 661,
    193 => 661,
    194 => 661,
    195 => 661,
    196 => 661,
    197 => 661,
    198 => 912,
    199 => 634,
    200 => 558,
    201 => 558,
    202 => 558,
    203 => 558,
    204 => 305,
    205 => 305,
    206 => 305,
    207 => 305,
    208 => 731,
    209 => 783,
    210 => 787,
    211 => 787,
    212 => 787,
    213 => 787,
    214 => 787,
    215 => 571,
    216 => 787,
    217 => 742,
    218 => 742,
    219 => 742,
    220 => 742,
    221 => 592,
    222 => 619,
    223 => 666,
    224 => 580,
    225 => 580,
    226 => 580,
    227 => 580,
    228 => 580,
    229 => 580,
    230 => 887,
    231 => 495,
    232 => 576,
    233 => 576,
    234 => 576,
    235 => 576,
    236 => 279,
    237 => 279,
    238 => 279,
    239 => 279,
    240 => 607,
    241 => 635,
    242 => 611,
    243 => 611,
    244 => 611,
    245 => 611,
    246 => 611,
    247 => 571,
    248 => 611,
    249 => 635,
    250 => 635,
    251 => 635,
    252 => 635,
    253 => 536,
    254 => 623,
    255 => 536,
    338 => 948,
    339 => 960,
    376 => 592,
    710 => 599,
    732 => 599,
    8192 => 465,
    8193 => 931,
    8194 => 465,
    8195 => 931,
    8196 => 310,
    8197 => 232,
    8198 => 155,
    8199 => 155,
    8200 => 116,
    8201 => 186,
    8202 => 51,
    8208 => 322,
    8209 => 322,
    8210 => 322,
    8211 => 500,
    8212 => 1000,
    8216 => 193,
    8217 => 193,
    8218 => 268,
    8220 => 397,
    8221 => 397,
    8222 => 461,
    8226 => 376,
    8230 => 819,
    8239 => 186,
    8249 => 336,
    8250 => 336,
    8287 => 232,
    8364 => 580,
    8482 => 762,
    57344 => 540,
    64257 => 642,
    64258 => 642,
    64259 => 1005,
    64260 => 1005,
  ),
  'CIDtoGID_Compressed' => true,
  'CIDtoGID' => 'eJzt0EOzKEYUhdEvtm3btm3btm3btm3btm3rXySDN3hVyUslVTe5k7Ump7pP1+nd3XANy/DD7AxthEZspEZulEZttEZvjMZsrMZunMZtvMZvgiZsoiZukiZtsiZviqZsqqZumqZtuqZvhmZspmZulmZttmZvjuZsruZunuZtvuZvgRZsoRZukRZtsRZviZZsqZZumZZtuZZvhVZspVZulVZttVZvjdZsrdZundZtvdZvgzZsozZukzZtszZvi7Zsq7Zum7Ztu3/0wr+3fTu0Yzu1c7u0a7u1e3u0Z3u1d/u0b/u1fwd0YAd1cId0aId1eEd0ZEd1dMd0bMd1fCd0Yid1cqd0aqd1emd0Zmd1dud0bud1fhd0YRd1cZd0aZd1eVd0ZVd1ddd0bdd1fTd0Yzd1c7d0a7d1e3d0Z3d1d/d0b/d1fw/0YA/1cI/0aI/1eE/0ZE/1dM/0bM8NwA/8957vhQGb9eKATYKB9dK/OPvyf5YCAAAAAAAAAAAAAAAAAIDB9Eqv9lqv90Zv9lZv907v9t5Q/ff7oA/7qI+HrD/p0z77o37eF305ZO+rIfXrP03/5i9u/LbvBiz99wM2aaD9MNgB/kc/DnYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABggPw12AAAAAAAAAAAAAAAAAACG4ed+6dd+G+wYAAD8H34Hgidqfg==',
  '_version_' => 6,
);